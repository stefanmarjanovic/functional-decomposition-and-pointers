#ifndef ASS2_H
#define ASS2_H
/********************************************************
* CSCI251/851 Assignment 2 
* ass2.h - Contains phone DB header file
* Put you name, login and the date last modified here
*
*********************************************************/

void ReadFile();
void DisplayRecords();
void AddRecord();
void SearchRecords();
void CleanUp();
void CheckRecord();
void WriteFile();

#endif

